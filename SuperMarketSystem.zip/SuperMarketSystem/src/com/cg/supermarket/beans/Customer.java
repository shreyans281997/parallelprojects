package com.cg.supermarket.beans;
import java.util.HashMap;
public class Customer {
	private int CustId;
	private String name;
	private String gstNumber;
	private String occupation;
	private String mobileNumber;
	private String address;
	private HashMap<Integer,Order> orders=new HashMap<>();
	public Customer(String name, String gstNumber, String occupation, String mobileNumber, String address) {
		super();
		this.name = name;
		this.gstNumber = gstNumber;
		this.occupation = occupation;
		this.mobileNumber = mobileNumber;
		this.address = address;
	}
	public Customer(int custId, String name, String gstNumber, String occupation, String mobileNumber, String address,
			HashMap<Integer, Order> orders) {
		super();
		CustId = custId;
		this.name = name;
		this.gstNumber = gstNumber;
		this.occupation = occupation;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.orders = orders;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGstNumber() {
		return gstNumber;
	}
	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public HashMap<Integer, Order> getOrders() {
		return orders;
	}
	public void setOrders(HashMap<Integer, Order> orders) {
		this.orders = orders;
	}

	public int getCustId() {
		return CustId;
	}

	public void setCustId(int custId) {
		CustId = custId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + CustId;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((gstNumber == null) ? 0 : gstNumber.hashCode());
		result = prime * result + ((mobileNumber == null) ? 0 : mobileNumber.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((occupation == null) ? 0 : occupation.hashCode());
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (CustId != other.CustId)
			return false;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (gstNumber == null) {
			if (other.gstNumber != null)
				return false;
		} else if (!gstNumber.equals(other.gstNumber))
			return false;
		if (mobileNumber == null) {
			if (other.mobileNumber != null)
				return false;
		} else if (!mobileNumber.equals(other.mobileNumber))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (occupation == null) {
			if (other.occupation != null)
				return false;
		} else if (!occupation.equals(other.occupation))
			return false;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", name=" + name + ", gstNumber=" + gstNumber + ", occupation="
				+ occupation + ", mobileNumber=" + mobileNumber + ", address=" + address + ", orders=" + orders + "]";
	}



}

