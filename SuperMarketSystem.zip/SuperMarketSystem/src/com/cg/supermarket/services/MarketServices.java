package com.cg.supermarket.services;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.supermarket.beans.Customer;
import com.cg.supermarket.beans.Order;
import com.cg.supermarket.exceptions.AlreadyRegisteredException;
import com.cg.supermarket.exceptions.CustomerNotFoundException;
import com.cg.supermarket.exceptions.InvalidMobileNumberException;
import com.cg.supermarket.exceptions.InvalidOccupationExcpetion;
public interface MarketServices {
	Customer acceptDetails(String name, String gstNumber, String occupation, String mobileNumber, String address) throws InvalidMobileNumberException, AlreadyRegisteredException, InvalidOccupationExcpetion;
	HashMap<Integer, Order> getOrders(int CustomerId) throws CustomerNotFoundException ;
	Customer getDetails(int CustomerId) throws CustomerNotFoundException;
	float getBill(int custId, ArrayList<String> product) throws CustomerNotFoundException;
	boolean checkProduct(String itemName);
}
