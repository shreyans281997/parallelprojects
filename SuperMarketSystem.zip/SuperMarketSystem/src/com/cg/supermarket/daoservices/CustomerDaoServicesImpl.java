package com.cg.supermarket.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.supermarket.beans.Customer;
import com.cg.supermarket.util.SuperMarketDB;

public class CustomerDaoServicesImpl implements CustomerDaoServices {

	@Override
	public Customer save(Customer customer) {
		customer.setCustId(SuperMarketDB.getCustomerId());
		SuperMarketDB.MarketDB.put(customer.getCustId(), customer);
		return customer;
	}
	@Override
	public Customer update(Customer customer) {
		return SuperMarketDB.MarketDB.put(customer.getCustId(), customer);
	}

	@Override
	public Customer findOne(int custId) {
		return SuperMarketDB.MarketDB.get(custId);
	}

	@Override
	public List<Customer>  findAll() {
		return new ArrayList<>(SuperMarketDB.MarketDB.values());
	}



	

}
